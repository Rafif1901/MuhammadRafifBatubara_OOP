package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class JumpState implements FighterState{
    private final Fighter fighter;

    public JumpState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void handleInput(PlayerInput input){
        if(input.right){
            fighter.getVelocity().x = 100f;
            fighter.setFacingRight(true);
        }
        if(input.left){
            fighter.getVelocity().x = -100f;
            fighter.setFacingRight(false);
        }
        else{
            fighter.getVelocity().x = 0;
        }
    }

    @Override
    public void enter(){}

    @Override
    public void exit(){}

    @Override
    public void update(float delta){}
}
