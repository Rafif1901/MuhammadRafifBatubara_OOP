package com.tp10;

public class PlayerInput {
    public boolean left = false;
    public boolean right = false;
    public boolean jump = false;
    public boolean crouch = false;
    public boolean punch = false;
    public boolean block = false;
}
