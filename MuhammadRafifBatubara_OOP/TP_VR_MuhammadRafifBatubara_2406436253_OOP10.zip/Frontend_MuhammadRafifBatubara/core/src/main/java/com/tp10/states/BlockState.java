package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class BlockState implements FighterState{
    private final Fighter fighter;

    public BlockState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void enter(){
        fighter.getVelocity().x = 0;
    }

    @Override
    public void handleInput(PlayerInput input){
        if(!input.block){
            fighter.changeState(new StandState(fighter));
        }
    }

    @Override
    public void exit(){}

    @Override
    public void update(float delta){}
}
