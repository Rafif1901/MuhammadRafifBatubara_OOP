package com.tp10;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.tp10.strategies.AggressiveStrategy;
import com.tp10.strategies.DefensiveStrategy;

public class Main extends ApplicationAdapter{
    private ShapeRenderer shapeRenderer;
    private OrthographicCamera camera;
    private Fighter player1;
    private Fighter player2;
    private PlayerInput playerInput;
    private Rectangle ground;
    private boolean isGameOver = false;

    @Override
    public void create() {
        shapeRenderer = new ShapeRenderer();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        playerInput = new PlayerInput();
        ground = new Rectangle(0, 0, Gdx.graphics.getWidth(), Fighter.GROUND_LEVEL);
        player1 = new Fighter("Player 1", new Vector2(Gdx.graphics.getWidth() / 2 - 100, Fighter.GROUND_LEVEL), true);
        player2 = new Fighter("Com", new Vector2(Gdx.graphics.getWidth() / 2 + 100, Fighter.GROUND_LEVEL), false);
        player2.setAI(new AggressiveStrategy(), player1);
    }

    @Override
    public void render(){
        float delta = Gdx.graphics.getDeltaTime();

        handleInput();
        if(!player1.isDead() && !player2.isDead()){
            player1.update(delta, playerInput);
            player2.update(delta, null);
            checkCollisions();
        }
        else{
            if(!isGameOver){
                System.out.println("=== Press R to Restart ===");
                isGameOver = true;
            }
        }

        Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        shapeRenderer.setProjectionMatrix(camera.combined);

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.GRAY);
        shapeRenderer.rect(ground.x, ground.y, ground.width, ground.height);

        drawFighter(player1, Color.BLUE);
        drawFighter(player2, Color.RED);

        shapeRenderer.end();
    }

    private void handleInput(){
        if((player1.isDead() || player2.isDead()) &&Gdx.input.isKeyJustPressed(Input.Keys.R)){
            resetGame();
            return;
        }
        if(player1.isDead() || player2.isDead()){
            return;
        }

        playerInput.left = Gdx.input.isKeyPressed(Input.Keys.A);
        playerInput.right = Gdx.input.isKeyPressed(Input.Keys.D);
        playerInput.jump = Gdx.input.isKeyJustPressed(Input.Keys.SPACE);
        playerInput.punch = Gdx.input.isKeyJustPressed(Input.Keys.H);
        playerInput.block = Gdx.input.isKeyPressed(Input.Keys.S);
    }

    private void checkCollisions(){
        if(player1.getHitbox().overlaps(player2.getCollider())){
            player2.takeHit(10);
        }
        if(player2.getHitbox().overlaps(player1.getCollider())){
            player1.takeHit(10);
        }
    }

    private void drawFighter(Fighter fighter, Color color){
        Rectangle collider = fighter.getCollider();
        shapeRenderer.setColor(color);
        shapeRenderer.rect(collider.x, collider.y, collider.width, collider.height);

        Rectangle hitbox = fighter.getHitbox();
        if(fighter.getHitbox().width > 0){
            shapeRenderer.setColor(color.ORANGE);
            shapeRenderer.rect(hitbox.x, hitbox.y, hitbox.width, hitbox.height);
        }
    }

    private void resetGame(){
        System.out.println("--- GAME RESTARTED ---");
        create();
    }



    @Override
    public void dispose(){
        shapeRenderer.dispose();
    }
}
