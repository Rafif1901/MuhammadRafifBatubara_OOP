package com.tp10;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.tp10.states.*;
import com.tp10.strategies.FightingStrategy;

public class Fighter {
    private Vector2 position;
    private Vector2 velocity;
    private Rectangle collider;
    private Rectangle hitbox;
    private int health;
    private FighterState currentState;
    private boolean isFacingRight;
    private FightingStrategy aiStrategy;
    private Fighter opponent;
    private boolean isAI;
    private String name;


    protected final float WALK_SPEED = 150f;
    protected final float JUMP_VELOCITY = 600f;

    public static final float GRAVITY = 1400f;
    public static final float GROUND_LEVEL = 100f;

    public Fighter(String name, Vector2 startPosition, boolean startsFacingRight){
        this.name = name;
        this.position = new Vector2(startPosition);
        this.isFacingRight = startsFacingRight;
        this.velocity = new Vector2();
        this.collider = new Rectangle(position.x - 20, position.y, 40, 100);
        this.hitbox = new Rectangle();
        this.health = 100;
        this.isAI = false;
        changeState(new StandState(this));
    }

    public void changeState(FighterState newState){
        if(currentState != null){
            currentState.exit();
        }
        this.currentState = newState;
        if(this.currentState != null) {
            this.currentState.enter();
        }
    }

    public void update(float delta, PlayerInput input){
        if(isAI && aiStrategy != null){
            aiStrategy.execute(this, opponent);
        }
        if(!isAI && input != null){
            currentState.handleInput(input);
        }
        currentState.update(delta);

        velocity.y -= GRAVITY * delta;
        position.add(velocity.x * delta, velocity.y * delta);

        if(position.y < GROUND_LEVEL){
            position.y = GROUND_LEVEL;
            velocity.y = 0;
            if(isInState(JumpState.class)) {
                changeState(new StandState(this));
            }
        }
        updateCollider();
    }

    public void takeHit(int damage){
        if(isInState(HitState.class) || health <= 0){
            return;
        }
        if(isInState(BlockState.class)){
            health -= 5;
        }else{
            health -= damage;
            changeState(new HitState(this));
        }
        System.out.println(this.name + " Health: " + health);
        if(health <= 0){
            System.out.println(this.name + " K.O");
            if(isAI){
                aiStrategy = null;
            }
        }
    }

    private void updateCollider(){
        collider.setPosition(position.x - collider.width / 2, position.y);
    }

    public boolean canChangeState(){
        if(!(currentState instanceof PunchState) && !(currentState instanceof HitState) && health > 0){
            return true;
        }
        return false;
    }

    public void setAI(FightingStrategy strategy, Fighter opponent){
        this.isAI = true;
        this.aiStrategy = strategy;
        this.opponent = opponent;
    }

    public void performStand(){
        if(canChangeState()){
            changeState(new StandState(this));
        }
    }

    public void performPunch(){
        if(canChangeState()){
            changeState(new PunchState(this));
        }
    }

    public void performBlock(){
        if(canChangeState()){
            changeState(new BlockState(this));
        }
    }

    public void performMoveLeft(){
        if(canChangeState()){
            isFacingRight = false;
            if(!isInState(WalkState.class)){
                changeState(new WalkState(this));
            }
            velocity.x = -WALK_SPEED;
        }
    }

    public void performMoveRight(){
        if(canChangeState()){
            isFacingRight = true;
            if(!isInState(WalkState.class)){
                changeState(new WalkState(this));
            }
            velocity.x = WALK_SPEED;
        }
    }

    public void performJump(){
        if(canChangeState() && position.y == GROUND_LEVEL){
            velocity.y = JUMP_VELOCITY;
            changeState(new JumpState(this));
        }
    }

    public boolean isDead(){
        return this.health <= 0;
    }

    public Vector2 getPosition(){
        return position;
    }

    public Vector2 getVelocity(){
        return velocity;
    }

    public Rectangle getCollider(){
        return collider;
    }

    public Rectangle getHitbox(){
        return hitbox;
    }

    public boolean isFacingRight(){
        return isFacingRight;
    }

    public void setFacingRight(boolean facingRight){
        isFacingRight = facingRight;
    }

    public FighterState getCurrentState(){
        return currentState;
    }

    public boolean isInState(Class<?> stateType){
        return stateType.isInstance(currentState);
    }
}
