package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class PunchState implements FighterState{
    private final Fighter fighter;
    private float attackTimer;
    private final float ATTACK_DURATION = 0.5f;

    public PunchState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void enter(){
        this.attackTimer = ATTACK_DURATION;
        fighter.getVelocity().x = 0;
        float hitboxX = fighter.getPosition().x;
        float offset = fighter.isFacingRight() ? 20f : -60f;
        float hitboxWidth = 40f;
        fighter.getHitbox().set(
            hitboxX + offset,
            fighter.getPosition().y + 50,
            hitboxWidth,
            20
        );
    }

    @Override
    public void update(float delta){
        attackTimer -= delta;
        if(attackTimer <= 0){
            fighter.changeState(new StandState(fighter));
        }
    }

    @Override
    public void exit(){
        fighter.getHitbox().set(0, 0, 0, 0);
    }

    @Override
    public void handleInput(PlayerInput input){}

}
