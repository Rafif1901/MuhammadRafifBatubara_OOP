package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class StandState implements FighterState{
    private final Fighter fighter;


    public StandState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void enter(){
        fighter.getVelocity().x = 0;
    }

    @Override
    public void handleInput(PlayerInput input){
        if(input.punch){
            fighter.performPunch();
        }
        else if(input.jump){
            fighter.performJump();
        }
        else if(input.block){
            fighter.performBlock();
        }
        else if(input.right){
            fighter.performMoveRight();
        }
        else if(input.left){
            fighter.performMoveLeft();
        }
    }

    @Override
    public void exit(){}

    @Override
    public void update(float delta){}
}
