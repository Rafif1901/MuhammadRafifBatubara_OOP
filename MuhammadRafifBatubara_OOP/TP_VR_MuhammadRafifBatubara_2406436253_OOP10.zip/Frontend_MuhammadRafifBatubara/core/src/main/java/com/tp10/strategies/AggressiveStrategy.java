package com.tp10.strategies;

import com.tp10.Fighter;

public class AggressiveStrategy implements FightingStrategy{
    private final float ATTACK_RANGE = 60f;

    @Override
    public void execute(Fighter self, Fighter opponent){
        if(!self.canChangeState()){
            return;
        }

        float distance = Math.abs(self.getPosition().x - opponent.getPosition().x);
        boolean isOpponentRight = opponent.getPosition().x > self.getPosition().x;

        if(distance <= ATTACK_RANGE){
            self.setFacingRight(isOpponentRight);
            self.performPunch();
        }
        else{
            if(isOpponentRight){
                self.performMoveRight();
            }
            else{
                self.performMoveLeft();
            }
        }
    }
}
