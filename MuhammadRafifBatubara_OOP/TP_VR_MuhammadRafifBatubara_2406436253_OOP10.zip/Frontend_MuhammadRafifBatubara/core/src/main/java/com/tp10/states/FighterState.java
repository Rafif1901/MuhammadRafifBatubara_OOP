package com.tp10.states;

import com.tp10.PlayerInput;

public interface FighterState {
    void enter();
    void exit();
    void update(float delta);
    void handleInput(PlayerInput input);
}
