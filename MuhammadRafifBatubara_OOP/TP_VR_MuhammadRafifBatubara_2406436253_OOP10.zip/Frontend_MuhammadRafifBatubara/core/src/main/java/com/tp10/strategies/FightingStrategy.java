package com.tp10.strategies;
import com.tp10.Fighter;

public interface FightingStrategy {
    void execute(Fighter self, Fighter opponent);
}
