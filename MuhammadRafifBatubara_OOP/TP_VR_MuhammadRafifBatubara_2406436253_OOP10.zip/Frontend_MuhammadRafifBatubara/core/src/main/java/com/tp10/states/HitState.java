package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class HitState implements FighterState{
    private final Fighter fighter;
    private float stunTimer;
    private final float STUN_DURATION = 0.3f;

    public HitState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void enter(){
        this.stunTimer = STUN_DURATION;
        fighter.getVelocity().x = 0;
    }

    @Override
    public void update(float delta){
        stunTimer -= delta;
        if(stunTimer <= 0){
            fighter.changeState(new StandState(fighter));
        }
    }

    @Override
    public void exit(){}

    @Override
    public void handleInput(PlayerInput input){}

}
