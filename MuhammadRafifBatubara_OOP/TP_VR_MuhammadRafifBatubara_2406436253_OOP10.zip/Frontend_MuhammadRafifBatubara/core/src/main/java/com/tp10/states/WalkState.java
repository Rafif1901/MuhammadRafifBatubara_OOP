package com.tp10.states;

import com.tp10.Fighter;
import com.tp10.PlayerInput;

public class WalkState implements FighterState{
    private final Fighter fighter;

    public WalkState(Fighter fighter){
        this.fighter = fighter;
    }

    @Override
    public void enter(){}

    @Override
    public void exit(){}

    @Override
    public void update(float delta){}

    @Override
    public void handleInput(PlayerInput input){
        if(input.punch){
            fighter.performPunch();
        }
        if(input.jump){
            fighter.performJump();
        }
        if(input.right){
            fighter.performMoveRight();
        }
        if(input.left){
            fighter.performMoveLeft();
        }
        else{
            fighter.changeState(new StandState(fighter));
        }
    }
}
