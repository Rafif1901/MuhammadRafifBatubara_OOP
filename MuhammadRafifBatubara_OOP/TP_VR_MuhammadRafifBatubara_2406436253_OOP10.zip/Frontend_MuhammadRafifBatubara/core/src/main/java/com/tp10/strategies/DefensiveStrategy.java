package com.tp10.strategies;

import com.tp10.Fighter;
import com.tp10.states.PunchState;

public class DefensiveStrategy implements FightingStrategy{
    private final float SAFE_DISTANCE = 100f;

    @Override
    public void execute(Fighter self, Fighter opponent){
        if(!self.canChangeState()){
            return;
        }

        float distance = Math.abs(self.getPosition().x - opponent.getPosition().x);
        boolean isOpponentRight = opponent.getPosition().x > self.getPosition().x;

        self.setFacingRight(isOpponentRight);

        if(opponent.isInState(PunchState.class) && distance < 80f){
            self.performBlock();
        }
        else if(distance < SAFE_DISTANCE){
            if(isOpponentRight){
                self.performMoveLeft();
            }
            else{
                self.performMoveRight();
            }
        }
        else{
            self.performStand();
        }
    }
}
