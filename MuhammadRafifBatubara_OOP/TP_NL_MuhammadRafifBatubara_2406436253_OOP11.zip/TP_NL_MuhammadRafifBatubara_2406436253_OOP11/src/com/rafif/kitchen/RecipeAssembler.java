package com.rafif.kitchen;

abstract public class RecipeAssembler {

    public final void makeRecipe(){
        prepareIngredient();
        cook();
        serve();
    }

    abstract protected void prepareIngredient();
    abstract protected void cook();
    protected void serve(){
        System.out.println("Step 3 [serve]: serving food on the plate");
    }
}
