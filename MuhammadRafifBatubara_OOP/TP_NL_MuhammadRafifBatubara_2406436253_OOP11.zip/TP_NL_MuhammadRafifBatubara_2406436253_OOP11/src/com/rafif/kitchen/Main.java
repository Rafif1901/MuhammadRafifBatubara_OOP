package com.rafif.kitchen;

public class Main {
    public static void main(String[] args){
        KitchenFacade kitchen = new KitchenFacade();

        RecipeAssembler pasta = new PastaRecipe();
        RecipeAssembler salad = new SaladRecipe();

        System.out.println("===#Order 1: Pasta====");
        kitchen.startCookingUp(pasta);

        System.out.println("\n===#Order 2: Salad====");

        kitchen.startCookingUp(salad);

        System.out.println("\n===All Orders are done===");
        kitchen.cleanUp();
    }
}
