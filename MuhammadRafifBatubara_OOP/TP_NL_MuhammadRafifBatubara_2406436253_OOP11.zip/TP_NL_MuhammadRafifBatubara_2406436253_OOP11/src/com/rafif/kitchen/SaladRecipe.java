package com.rafif.kitchen;

public class SaladRecipe extends RecipeAssembler{
    @Override
    protected void prepareIngredient(){
        System.out.println("Step 1 [prep]: preparing and cutting vegetables(eg. cucumber, cherry tomatoes, lettuce), and mayo sauce");
    }

    @Override
    protected void cook(){
        System.out.println("Step 2 [cook]: mix all vegetables and mayo sauce");
    }
}
