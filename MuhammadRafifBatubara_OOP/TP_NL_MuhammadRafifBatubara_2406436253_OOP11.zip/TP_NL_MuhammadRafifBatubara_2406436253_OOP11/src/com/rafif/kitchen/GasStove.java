package com.rafif.kitchen;

public class GasStove {
    public void turnOn(){
        System.out.println("Turning on the stove");
    }

    public void turnOff(){
        System.out.println("Turning off the stove");
    }
}
