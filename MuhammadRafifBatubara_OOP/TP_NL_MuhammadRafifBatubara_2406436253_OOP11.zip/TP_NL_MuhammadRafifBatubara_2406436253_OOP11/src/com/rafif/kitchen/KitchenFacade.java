package com.rafif.kitchen;

public class KitchenFacade {
    private KitchenSink sink;
    private GasStove stove;

    public KitchenFacade(){
        sink = new KitchenSink();
        stove = new GasStove();
    }

    public void startCookingUp(RecipeAssembler recipe){
        stove.turnOn();
        System.out.println("Start Cooking");
        recipe.makeRecipe();
        stove.turnOff();
        System.out.println("Food is ready");
    }

    public void cleanUp(){
        System.out.println("Cleaning up the kitchen");
        sink.washDishes();
    }
}
