package com.rafif.kitchen;

public class PastaRecipe extends RecipeAssembler{

    @Override
    protected void prepareIngredient(){
        System.out.println("Step 1 [prep]: preparing pasta, oil, chilli, and water");
    }

    @Override
    protected void cook(){
        System.out.println("Step 2 [cook]: boiling water, adding pasta to boiling water");
        System.out.println("mix cooked pasta with chilli and oil");
    }
}
