package com.rafif.kitchen;

public class KitchenSink {
    public void washDishes(){
        System.out.println("Washing dirty cook utensils");
    }
}
